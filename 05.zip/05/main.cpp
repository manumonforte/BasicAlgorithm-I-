﻿// Manuel Monforte Escobar
// E37

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include "conjunto.h"



// función que resuelve el problema si se trata de numeros
void resolverNumeros(set<long int>&lista, int k) {
	int x;
	std::cin >> x;
	int mayor = x;
	set<int>sol;
	while (x != -1){//rellenamos lista
			lista.insert(x);
		std::cin >> x;
	}
	while (lista.size() > k){
		lista.eraseLess();
	}
	for (int i = 0; i < k; i++){
		std::cout << lista.showLess() << " ";
		lista.eraseLess();
	}

}
// función que resuelve el problema si se trata de letras

void resolverLetras(set<std::string> &lista,int k) {
	std::string x;
	std::cin >> x;
	std::string mayor = x;
	set<std::string>sol;
	while (x != "FIN"){//rellenamos lista
		if (!lista.contains(x)){
			lista.insert(x);
		}
		std::cin >> x;
	}
	while (lista.size() > k){
		lista.eraseLess();
	}
	for (int i = 0; i < k; i++){
		std::cout << lista.showLess() << " ";
		lista.eraseLess();
	}
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
	// leer los datos de la entrada
	char tipo;
	int k = 0;
	std::cin >> tipo;
	if (!std::cin)
		return false;
	std::cin >> k;
	switch (tipo){
	case 'P':{//si es letras
		set<std::string> lista;
		resolverLetras(lista,k);
	}break;
	case 'N':{ //si es numeros
		set<long int>lista;
		resolverNumeros(lista,k);
	}break;
	};
	std::cout << "\n";
	return true;
	
}

int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


	while (resuelveCaso())
		;


	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif

	return 0;
}